MyLifeOrganized Application
----------------------------

Thank you for downloading MyLifeOrganized application (MLO).

Web site:           http://www.mylifeorganized.net/
Discussion group:   http://groups.google.com/group/MyLifeOrganized
Reviews:            http://www.mylifeorganized.net/products/my-life-organized/reviews-and-articles.html
E-mail:	            info@mylifeorganized.net



What is MyLifeOrganized?
-------------------------

MyLifeOrganized is a simple yet powerful personal time and task management 
software application. Use built-in outliner to organize your 
goals, projects and tasks into a tree and MyLifeOrganized will generate a simple
to-do list of actions for you. This list will contain only those actions 
which require immediate attention and will be sorted in order of priority 
so that you can stay focused on what is really important to you. The PocketPC edition
of MyLifeOrganized could be synced with desktop editon. MyLifeOrganized 
can also be synced with your MS Outlook. Simply minimize MLO to your system tray 
where it is available for your next thought or task.

Please visit http://www.mylifeorganized.net for more details.
Join MLO community at:   http://groups.google.com/group/MyLifeOrganized


How to install
--------------
1. If you downloaded MLO installer "MLO-Setup.exe" just run it and follow the instructions.
   Previous MLO versions will be updated automatically (no uninstall needed)
2. If you downloaded zip file: "mlo.zip" then no installation needed. Just unzip files 
   to a folder of your choice and run the application mlo.exe. 


How to uninstall
----------------
1. If you used MLO installer to install the program use "Add or Remove Programs" from your Windows Control Panel 
   to completely uninstall MLO.
2. If you used zip archive to install MLO, simply delete all the files from the folder you copied the application to.



Installing components needed to sync with PocketPC 
--------------------------------------------------- 
There is a PocketPC edition of MyLifeOrganized application which can be synced with Desktop edition. 
You can download MLO PocketPC edition from official site: http://www.mylifeorganized.net/downloads/ 

To sync tasks with MyLifeOrganized PocketPC edition there should be two components installed: 
1) MLO-Desktop application with Windows Mobile Sync Manager (Desktop side) 
2) MLO-PocketPC application with ActiveSync Provider (PocketPC side) 


How to install or update MLO Windows Mobile Sync Manager 
1) If you already have previous version of MLO Windows Mobile Sync Manager installed 
  1.1) Uncradle your device 
  1.2) Close ActiveSync window. (This is needed to release all used dlls). 
  1.3) Close MLO Windows Mobile Sync Manager window (located in tray)
2) Run MLO-Setup.exe 
3) On the Components page of the installation wizard select "Windows Mobile Sync" check box. 
5) Click Next and follow the instructions. 

      Note: You might need to have administrator rights on your 
            computer to install MLO Windows Mobile Sync Manager.  


How to install or update MLO PocketPC on your device 
1) Close MyLifeOrganized PocketPC application on your device 
2) Cradle your device 
3) Download from website EXE or CAB installation and follow the instructions to install MLO-PocketPC on your device 
4) Perform soft reset of your device if installation program warns you that it is needed 

Once you installed all the components you need to configure the synchronization. 
Please refer to the help documentation for more details about sync configuration.



Files
-----
mlo.exe				- MyLifeOrganized application
mlo.chm				- Help documentation
MLOWMSync.exe			- MLO Windows Mobile Sync Manager (optional). Used to sync with MLO-PocketPC edition
mloSync.dll			- MLO data provider (optional). Used to access MLO data files during sync to MLO-PocketPC edition
MLOWiFiSync.dll                 - MLO WiFi sync module (optional). Used to sync with MyLifeOrganized on mobile devices using WiFi
MLOWMSync.exe.log		- MLO Windows Mobile Sync Manager log file
mloSync.dll.log			- MLO data provider log file

Templates\*.mlt			- MLO templates
Reports\*.*			- MLO print report templates
Reports\PocketMod\*.*          	- MLO PocketMod report templates
Sound\*.*			- MLO reminders sound files
Themes\*.mlthm                  - MLO themes


LICENSE
-------
There are three versions of MyLifeOrganized application: 

1) Freeware version - Light Edition with limited functionality
2) Free 45-day Trial Version 
3) Registered version (Standard Edition or Professional Edition). 

You can find out what version you have by checking the About window 
at Help->About menu.

MyLifeOrganized trial version is a commercial application. You can use it
free of charge for evaluation purposes for no more then 45 days. After that
you  need  to  register  your  copy.  Please read license.txt for licensing
terms.


Distribution
------------
You can freely distribute this archive.
Please inform us via e-mail ( info@mylifeorganized.net ) about that.


MyLifeOrganized - Change Log
-----------------------------
The complete change log can be found on our website:
http://www.mylifeorganized.net/products/my-life-organized/change-log.htm




--------------
Thanks to Mark James for his Silk icon set we used in MyLifeOrganized application: 
http://www.famfamfam.com/lab/icons/silk/
